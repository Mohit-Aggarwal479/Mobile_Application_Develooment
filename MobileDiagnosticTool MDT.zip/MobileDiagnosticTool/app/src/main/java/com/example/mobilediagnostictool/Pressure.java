package com.example.mobilediagnostictool;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class Pressure extends AppCompatActivity {
    //SensorManager lets you access the device's sensors
    //declare Variables
    TextView textView;
    private SensorManager sensorManager;
    @SuppressLint({"RestrictedApi", "ClickableViewAccessibility"})
    @RequiresApi(api = Build.VERSION_CODES.N)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pressure);

        TextView actionEvent = findViewById(R.id.actionEvent);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE) != null) {
            actionEvent.setText("PRESSURE sensor supports");
        } else {
            actionEvent.setText("no PRESSURE sensor supports");
        }
    }

}
