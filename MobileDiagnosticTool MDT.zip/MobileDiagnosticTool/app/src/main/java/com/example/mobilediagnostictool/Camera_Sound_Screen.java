package com.example.mobilediagnostictool;

import android.content.Intent;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Camera_Sound_Screen extends AppCompatActivity {
    private Button button;
    private Button button1;
    private Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Display display = getWindowManager().getDefaultDisplay();
        int width = display.getWidth();
        int height = display.getHeight();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.camera_sound_screen);
        button = (Button) findViewById(R.id.logs);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity();
            }
        });

        button1 = (Button) findViewById(R.id.int_ext_test);
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.beep);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mp.start();
            }
        });

        // Declare the button from the layout file
        button2 = (Button) findViewById(R.id.report);

                // Action when the button is clicked
        button2.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    Display display = getWindowManager().getDefaultDisplay();
                    Point m_size = new Point();
                    display.getSize(m_size);
                    int m_width = m_size.x;
                    int m_height = m_size.y;

                    Toast.makeText(getApplicationContext(),"height and width: "+m_height+"x"+m_width,Toast.LENGTH_SHORT).show();}
            });


    }

    public void openActivity() {
        // Android Open Camera
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        startActivity(intent);
    }

}
