package com.example.mobilediagnostictool;

import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Environment_sensor extends AppCompatActivity implements SensorEventListener{

    TextView textView;
    SensorManager sensorManager;
    Sensor sensor;

    //Ambient Temprature
    private TextView textView1;
    private SensorManager sensorManager1;
    private Sensor tempSensor;
    private Boolean isTemperatureSensorAvailable;


    //Pressure
    Button button;

    //Humidity
    Button button1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.environment_sensor);

        //Light Sensor
        textView = (TextView) findViewById(R.id.textView17);
        sensorManager = (SensorManager) getSystemService(Service.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        //Ambient Temprature

        textView1 = (TextView) findViewById(R.id.textView19);
        sensorManager1 = (SensorManager) getSystemService(Service.SENSOR_SERVICE);

        if (sensorManager1.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE) !=null){
            tempSensor = sensorManager1.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
            isTemperatureSensorAvailable = true;
        }
        else {
            textView1.setText("Temprature Sensor is not Available");
            isTemperatureSensorAvailable = false;
        }

        //Pressure
        button = (Button) findViewById(R.id.pressure);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity();
            }
        });

        //Humidity
        button1 = (Button) findViewById(R.id.humidity_sensor);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity1();
            }
        });
    }

    @Override
    protected void onPause(){
        super.onPause();
        sensorManager.unregisterListener(this);
        //Ambient
        if (isTemperatureSensorAvailable) {
            sensorManager1.unregisterListener(this);
        }

    }

    @Override
    protected void onResume(){
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
        //Ambient Temperature
        if (isTemperatureSensorAvailable) {
            sensorManager1.registerListener(this, tempSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if (event.sensor.getType() == Sensor.TYPE_LIGHT) {
            textView.setText("" + event.values[0]);
        }

        //Ambient Temprature
        if (event.sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE) {
            textView1.setText(event.values[0]+" °C");
        }


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy){

    }


    public void openActivity() {
        Intent intent = new Intent(this, Pressure.class);
        startActivity(intent);
    }

    public void openActivity1() {
        Intent intent = new Intent(this, Humidity.class);
        startActivity(intent);
    }

}
