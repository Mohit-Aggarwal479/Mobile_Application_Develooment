package com.example.mobilediagnostictool;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Sensor_Menu extends AppCompatActivity {
    private Button button;
    private Button button1;
    private Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sensor);

        button = (Button) findViewById(R.id.motion_sensor);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity1();
            }
        });

        button1 = (Button) findViewById(R.id.position_sensor);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });

        button2 = (Button) findViewById(R.id.environment_sensor);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity3();
            }
        });
    }

    public void openActivity1() {
        Intent intent = new Intent(this, Motion_Sensor.class);
        startActivity(intent);
    }

    public void openActivity2() {
        Intent intent = new Intent(this, Position_sensor.class);
        startActivity(intent);
    }

    public void openActivity3() {
        Intent intent = new Intent(this, Environment_sensor.class);
        startActivity(intent);
    }
}
