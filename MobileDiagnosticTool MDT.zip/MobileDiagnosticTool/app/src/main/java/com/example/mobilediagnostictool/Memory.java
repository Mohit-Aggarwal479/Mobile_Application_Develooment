package com.example.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.text.format.Formatter;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
public class Memory extends AppCompatActivity {

    private TextView memoryStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memory_status);

        Log.d("getFreeInternalMemory:",Long.toString(getFreeInternalMemory()));
        Log.d("getFreeExternalMemory:",Long.toString(getFreeExternalMemory()));
        Log.d("getFreeSystemMemory:",Long.toString(getFreeSystemMemory()));


        Log.d("final:",memSize("/sdcard"));
        //Log.d("getFreeInternalMemory:",Long.toString(getFreeMemory());


        memoryStatus=findViewById(R.id.memory_status);
        memoryStatus.setText(memSize("sdcard"));

    }
    public long getFreeInternalMemory()
    {
        return getFreeMemory(Environment.getDataDirectory());
    }

    // Get external (SDCARD) free space
    public long getFreeExternalMemory()
    {
        return getFreeMemory(Environment.getExternalStorageDirectory());
    }

    // Get Android OS (system partition) free space
    public long getFreeSystemMemory()
    {
        return getFreeMemory(Environment.getRootDirectory());
    }

    // Get free space for provided path
// Note that this will throw IllegalArgumentException for invalid paths
    public long getFreeMemory(File path)
    {
        StatFs stats = new StatFs(path.getAbsolutePath());
        return stats.getAvailableBlocksLong() * stats.getBlockSizeLong();
    }




    private String memSize(String path){
        StatFs stat = new StatFs(path);
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        long freeBlocks = stat.getFreeBlocks();
        long countBlocks = stat.getBlockCount();
        String fileSize = Formatter.formatFileSize(this, availableBlocks * blockSize);
        String maxSize = Formatter.formatFileSize(this, countBlocks * blockSize);

        String info = path.toString()
                + "\nblockSize : " + Long.toString(blockSize)
                + "\navailableBlocks : " + Long.toString(availableBlocks)
                + "\nfreeBlocks : " + Long.toString(freeBlocks)
                + "\nreservedBlocks : " + Long.toString(freeBlocks - availableBlocks)
                + "\ncountBlocks : " + Long.toString(countBlocks)
                + "\nspace : " + fileSize + " / " + maxSize
                + "\n\n";
        return info;
    }

}
