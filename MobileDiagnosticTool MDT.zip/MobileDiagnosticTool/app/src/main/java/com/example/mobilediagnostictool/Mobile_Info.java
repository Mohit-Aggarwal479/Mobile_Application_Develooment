package com.example.mobilediagnostictool;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Mobile_Info extends AppCompatActivity {

    // text view to display information
    private TextView textViewSetInformation;

    // button to get information
    private Button buttonGetInformation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mobilr_info);


        //initializing the views
        initViews();

        // initializing the listeners
        initListeners();

    }


    /**
     * method to initialize the views
     */
    private void initViews() {

        textViewSetInformation = (TextView) findViewById(R.id.textViewSetInformation);

        buttonGetInformation = (Button) findViewById(R.id.buttonGetInformation);

    }

    /**
     * method to initialize the listeners
     */
    private void initListeners() {

        buttonGetInformation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get hardware and software information
                String information = getHardwareAndSoftwareInfo();

                // set information to text view
                textViewSetInformation.setText(information);

            }
        });

    }

    /**
     * method to fetch hardware and software information
     *
     * @return information
     */
    private String getHardwareAndSoftwareInfo() {


        return getString(R.string.device) + " " + Build.DEVICE + "\n" +
                getString(R.string.model) + " " + Build.MODEL + "\n" +
                getString(R.string.id) + " " + Build.ID + "\n" +
                getString(R.string.user) + " " + Build.USER + "\n" +
                getString(R.string.base) + " " + Build.VERSION_CODES.BASE + "\n" +
                getString(R.string.incremental) + " " + Build.VERSION.INCREMENTAL + "\n" +
                getString(R.string.board) + " " + Build.BOARD + "\n" +
                getString(R.string.versioncode) + " " + Build.VERSION.RELEASE;

    }
}
