package com.example.mobilediagnostictool;

public class Temprature {
}
